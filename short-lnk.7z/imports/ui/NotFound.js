import React from 'react';

export default class NotFound extends React.Component {

  render(){
    return ( <p>404 Ups</p> )
  }

}
